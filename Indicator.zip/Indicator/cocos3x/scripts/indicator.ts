import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

/**
 * 로딩 인디케이터 컴포넌트
 * loading 자식 노드를 회전시켜 로딩 애니메이션 표시
 *
 * 사용법:
 * 1. indicator.prefab을 프로젝트에 복사
 * 2. 이 스크립트를 프로젝트의 scripts 폴더에 복사
 * 3. indicatorManager를 통해 show()/hide() 호출
 *
 * 구조:
 * - indicator (root node + indicator component)
 *   - Sprite (배경 어둡게 처리, 3000x3000, 반투명 검정)
 *   - loading (회전하는 로딩 스피너 이미지)
 */
@ccclass('indicator')
export class indicator extends Component {
    /** 회전할 loading 스프라이트 노드 */
    private loadingNode: Node = null;

    /** 회전 간격 (초) */
    @property({ tooltip: '회전 간격 (초)' })
    rotationInterval: number = 0.1;

    /** 한 번에 회전할 각도 (9개 점 기준 40도) */
    private readonly ROTATION_STEP: number = 40;

    /** 경과 시간 */
    private elapsedTime: number = 0;

    /** 애니메이션 활성화 상태 */
    private isAnimating: boolean = true;

    start() {
        // loading 노드 찾기
        this.loadingNode = this.node.getChildByName('loading');
    }

    onEnable() {
        // 활성화 시 애니메이션 재개
        this.isAnimating = true;
        this.elapsedTime = 0;
    }

    onDisable() {
        // 비활성화 시 애니메이션 멈춤
        this.isAnimating = false;
    }

    update(deltaTime: number) {
        if (!this.loadingNode || !this.isAnimating) return;

        this.elapsedTime += deltaTime;

        // 일정 간격마다 40도씩 회전
        if (this.elapsedTime >= this.rotationInterval) {
            this.elapsedTime = 0;
            this.loadingNode.angle -= this.ROTATION_STEP;
        }
    }
}
