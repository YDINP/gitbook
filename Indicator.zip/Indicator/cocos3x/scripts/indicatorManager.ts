import { Node, Prefab, instantiate, director, assetManager, AssetManager, resources, Color, Sprite, UITransform, Widget } from 'cc';

/**
 * 로딩 인디케이터 매니저 (싱글톤)
 * 광고 로딩, 네트워크 요청 등 대기 시간에 인디케이터 표시
 *
 * 사용법:
 * ```typescript
 * import { indicatorManager } from './indicatorManager';
 *
 * // 인디케이터 표시
 * await indicatorManager.show();
 *
 * // 인디케이터 숨기기
 * indicatorManager.hide();
 *
 * // 표시 중인지 확인
 * if (indicatorManager.isShowing()) { ... }
 * ```
 *
 * 설정:
 * - Bundle 방식: indicatorManager.setPath('bundleName', 'path/to/prefab');
 * - Resources 방식: indicatorManager.setResourcesPath('path/to/prefab');
 */
class IndicatorManager {
    private indicatorNode: Node = null;
    private isLoading: boolean = false;
    private cachedPrefab: Prefab = null;

    /** 로딩 방식 ('bundle' | 'resources') */
    private loadMode: 'bundle' | 'resources' = 'resources';

    /** 번들 이름 (bundle 모드) */
    private bundleName: string = 'prefabs';

    /** 프리펩 경로 */
    private prefabPath: string = 'ui/indicator';

    /**
     * 인디케이터 표시
     * @param parent 부모 노드 (미지정 시 현재 씬의 Canvas)
     */
    async show(parent?: Node): Promise<void> {
        if (this.isLoading || this.indicatorNode) return;

        this.isLoading = true;

        try {
            // 캐시된 프리펩 사용 또는 새로 로드
            let prefab = this.cachedPrefab;
            if (!prefab) {
                prefab = await this.loadPrefab();
                if (prefab) {
                    this.cachedPrefab = prefab;
                }
            }

            if (prefab) {
                this.indicatorNode = instantiate(prefab);
            } else {
                // 프리펩 없으면 간단한 대체 UI 생성
                console.warn('[IndicatorManager] Prefab not found, creating simple indicator');
                this.indicatorNode = this.createSimpleIndicator();
            }

            // 부모 노드 결정
            const targetParent = parent || director.getScene()?.getChildByName('Canvas');
            if (targetParent && this.indicatorNode) {
                targetParent.addChild(this.indicatorNode);
                console.log('[IndicatorManager] Indicator shown');
            }
        } catch (err) {
            console.error('[IndicatorManager] Error showing indicator:', err);
        } finally {
            this.isLoading = false;
        }
    }

    /**
     * 인디케이터 숨기기 및 제거
     */
    hide(): void {
        if (this.indicatorNode) {
            this.indicatorNode.destroy();
            this.indicatorNode = null;
            console.log('[IndicatorManager] Indicator hidden');
        }
    }

    /**
     * 인디케이터 표시 중인지 확인
     */
    isShowing(): boolean {
        return this.indicatorNode !== null;
    }

    /**
     * Bundle 모드로 경로 설정
     * @param bundleName 번들 이름
     * @param prefabPath 번들 내 프리펩 경로
     */
    setPath(bundleName: string, prefabPath: string): void {
        this.loadMode = 'bundle';
        this.bundleName = bundleName;
        this.prefabPath = prefabPath;
        this.cachedPrefab = null; // 경로 변경 시 캐시 초기화
    }

    /**
     * Resources 모드로 경로 설정
     * @param prefabPath resources 폴더 내 프리펩 경로
     */
    setResourcesPath(prefabPath: string): void {
        this.loadMode = 'resources';
        this.prefabPath = prefabPath;
        this.cachedPrefab = null;
    }

    /**
     * 프리펩 로드
     */
    private async loadPrefab(): Promise<Prefab | null> {
        if (this.loadMode === 'bundle') {
            return this.loadPrefabFromBundle();
        } else {
            return this.loadPrefabFromResources();
        }
    }

    /**
     * Resources에서 프리펩 로드
     */
    private loadPrefabFromResources(): Promise<Prefab | null> {
        return new Promise((resolve) => {
            resources.load(this.prefabPath, Prefab, (err, prefab) => {
                if (err) {
                    console.warn(`[IndicatorManager] Failed to load prefab from resources: ${this.prefabPath}`, err.message);
                    resolve(null);
                } else {
                    console.log(`[IndicatorManager] Prefab loaded from resources: ${this.prefabPath}`);
                    resolve(prefab);
                }
            });
        });
    }

    /**
     * 번들에서 프리펩 로드
     */
    private loadPrefabFromBundle(): Promise<Prefab | null> {
        return new Promise((resolve) => {
            // 번들 로드
            assetManager.loadBundle(this.bundleName, (err, bundle: AssetManager.Bundle) => {
                if (err) {
                    console.warn(`[IndicatorManager] Failed to load bundle: ${this.bundleName}`, err.message);
                    resolve(null);
                    return;
                }

                // 번들에서 프리펩 로드
                bundle.load(this.prefabPath, Prefab, (err, prefab) => {
                    if (err) {
                        console.warn(`[IndicatorManager] Failed to load prefab: ${this.prefabPath}`, err.message);
                        resolve(null);
                    } else {
                        console.log(`[IndicatorManager] Prefab loaded from bundle: ${this.bundleName}/${this.prefabPath}`);
                        resolve(prefab);
                    }
                });
            });
        });
    }

    /**
     * 프리펩 없을 때 간단한 인디케이터 생성
     */
    private createSimpleIndicator(): Node {
        const node = new Node('Indicator');

        // 전체 화면 어둡게
        const bg = new Node('bg');
        bg.addComponent(UITransform).setContentSize(2000, 2000);
        const bgSprite = bg.addComponent(Sprite);
        bgSprite.color = new Color(0, 0, 0, 150);
        bgSprite.type = Sprite.Type.SIMPLE;
        bgSprite.sizeMode = Sprite.SizeMode.CUSTOM;
        node.addChild(bg);

        // 로딩 노드 (간단한 대체)
        const loading = new Node('loading');
        loading.addComponent(UITransform).setContentSize(100, 100);
        node.addChild(loading);

        // Widget으로 화면 중앙 배치
        const widget = node.addComponent(Widget);
        widget.isAlignTop = widget.isAlignBottom = widget.isAlignLeft = widget.isAlignRight = true;
        widget.top = widget.bottom = widget.left = widget.right = 0;

        return node;
    }
}

/** 싱글톤 인스턴스 */
export const indicatorManager = new IndicatorManager();
