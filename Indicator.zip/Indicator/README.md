# Indicator Module

로딩 인디케이터 모듈 - 광고 로딩, 네트워크 요청 등 대기 시간에 표시하는 로딩 UI

## 지원 버전

| 폴더 | Cocos Creator 버전 | 상태 |
|------|-------------------|------|
| `cocos3x/` | 3.x | 완료 |
| `cocos2x/` | 2.x | 미지원 (해당 프로젝트 없음) |

## 폴더 구조

```
Indicator/
├── README.md                    # 이 문서
├── cocos3x/                     # Cocos Creator 3.x용
│   ├── scripts/
│   │   ├── indicator.ts         # 인디케이터 컴포넌트
│   │   └── indicatorManager.ts  # 인디케이터 매니저 (싱글톤)
│   ├── prefab/
│   │   ├── indicator.prefab     # 프리펩 파일
│   │   └── indicator.prefab.meta
│   └── images/
│       ├── loading.png          # 로딩 스피너 이미지
│       └── loading_alt.png      # 대체 로딩 이미지
└── cocos2x/                     # Cocos Creator 2.x용 (예정)
```

## 사용법

### 1. 파일 복사

프로젝트에 다음 파일들을 복사:

```
your-project/
├── assets/
│   ├── scripts/
│   │   └── utils/ (또는 원하는 위치)
│   │       ├── indicator.ts
│   │       └── indicatorManager.ts
│   └── resources/  (또는 bundles)
│       └── prefab/
│           └── ui/
│               └── indicator.prefab
```

### 2. 프리펩 설정

1. `indicator.prefab`을 Cocos Creator에서 열기
2. `loading` 노드의 Sprite에 `loading.png` 이미지 할당
3. 프리펩 저장

### 3. 코드에서 사용

```typescript
import { indicatorManager } from './utils/indicatorManager';

// 기본 사용법
async function loadSomething() {
    // 인디케이터 표시
    await indicatorManager.show();

    try {
        // 네트워크 요청 또는 무거운 작업
        await fetchData();
    } finally {
        // 인디케이터 숨기기
        indicatorManager.hide();
    }
}

// 특정 부모 노드에 표시
await indicatorManager.show(myCanvasNode);

// 표시 중인지 확인
if (indicatorManager.isShowing()) {
    console.log('로딩 중...');
}
```

### 4. 경로 설정

#### Resources 폴더 사용 시 (기본값)
```typescript
// 기본 경로: 'ui/indicator'
indicatorManager.setResourcesPath('prefab/ui/indicator');
```

#### Bundle 사용 시
```typescript
// 번들 이름과 프리펩 경로 지정
indicatorManager.setPath('prefabs', 'UI/indicator');
```

## 프리펩 구조

```
indicator (Node)
├── indicator (Component) - 회전 애니메이션 제어
├── UITransform (100x100)
│
├── Sprite (Node) - 배경 어둡게
│   ├── UITransform (3000x3000)
│   └── Sprite (Color: 0,0,0,111)
│
└── loading (Node) - 회전하는 로딩 스피너
    ├── UITransform (102x102)
    └── Sprite (loading.png)
```

## 커스터마이징

### 회전 속도 조절
`indicator.ts`의 `rotationInterval` 프로퍼티 수정:
- 기본값: 0.1초
- 값이 작을수록 빠르게 회전

### 회전 각도 조절
`indicator.ts`의 `ROTATION_STEP` 상수 수정:
- 기본값: 40도 (9개 점 스피너 기준)
- 12개 점 스피너: 30도
- 8개 점 스피너: 45도

### 배경 투명도 조절
`indicator.prefab`의 Sprite 노드 Color alpha 값 수정:
- 기본값: 111 (약 43% 투명)
- 값이 클수록 어두움 (0-255)

## 출처 프로젝트

- FriendMaker (Cocos Creator 3.x)
- FriendsTileMatch (Cocos Creator 3.x)

## 업데이트 이력

- 2025-01-20: 초기 추출 및 통합
